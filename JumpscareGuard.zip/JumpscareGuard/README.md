# Jumpscare Bekçisi

Seçtiğin uygulamalara girince ekranda jumpscare (korkutucu yüz + ses + titreşim) çıkaran Android uygulaması.
İnternet gerektirmez, görsel/ses dosyası yoktur (hepsi kodla üretilir).

## Özellikler
- Telefondaki uygulamaların listesi; istediğini seç / kaldır, arama kutusu var
- Günlük süre sınırı: `0` = seçili uygulamaya her girişte korkut; `N` dakika = seçili uygulamalarda
  o gün N dakikayı aştıktan sonra korkut (süre dolduktan sonra bekleme süresi geçtikçe tekrar eder)
- İki korkutma arası en az süre, ses aç/kapa, korkuttuktan sonra ana ekrana atma
- Test düğmesi ve günlük sayaç

## İzin
Tek izin: **Erişilebilirlik**. Uygulama ilk açılışta izin ister ve seni ayarlara götürür.
"Diğer uygulamaların üstünde göster" izni **istemez**; jumpscare erişilebilirlik hizmetinin kendi pencere türüyle çizilir.
Android 13+ ile APK'yı dışarıdan kurduysan izin gri olabilir: Uygulama bilgisi → ⋮ → "Kısıtlı ayarlara izin ver".

## APK'yı üretme

### Yol 1 — Android Studio (bilgisayar)
1. Android Studio'yu aç → Open → bu klasörü seç, senkronizasyonun bitmesini bekle.
2. Build → Build APK(s).
3. `app/build/outputs/apk/debug/app-debug.apk` dosyasını telefona at ve kur
   ("Bilinmeyen kaynaklardan kuruluma izin ver" gerekir).

### Yol 2 — GitHub ile otomatik (Android Studio kurmadan)
1. github.com'da ücretsiz bir depo (repository) oluştur.
2. Bu klasörün içindekileri depoya yükle (Add file → Upload files).
   `.github/workflows/build.yml` yüklenmezse: Add file → Create new file → adı
   `.github/workflows/build.yml` yaz ve dosyanın içeriğini yapıştır.
3. Depoda **Actions** sekmesi → "APK derle" → Run workflow (push'ta da otomatik çalışır).
4. Bitince çalıştırmaya tıkla → en alttaki **Artifacts** bölümünden `JumpscareBekcisi-apk` indir,
   zip'ten çıkan `app-debug.apk`'yı telefona kur.

## Notlar
- minSdk 26 (Android 8.0+), targetSdk 34.
- Bu proje yazıldığı ortamda derlenip gerçek telefonda denenemedi; ilk derlemede hata çıkarsa hata mesajını paylaş.
