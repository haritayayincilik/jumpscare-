package com.jumpscare.guard;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.IntConsumer;

public class MainActivity extends Activity {
    private static final int BG = 0xFF121212;
    private static final int CARD = 0xFF1E1E1E;
    private static final int ACCENT = 0xFFE53935;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int SUB = 0xFFB0B0B0;

    private Prefs prefs;
    private Set<String> selected;
    private TextView permStatus;
    private TextView usageTv;
    private TextView countTv;
    private Button permBtn;
    private LinearLayout appBox;
    private final List<AppRow> rows = new ArrayList<AppRow>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            handler.postDelayed(this, 2000);
        }
    };

    private static class AppItem {
        String pkg;
        String label;
        Drawable icon;
    }

    private static class AppRow {
        String pkg;
        String label;
        View view;
    }

    private abstract static class Watcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int a, int b, int c) {
        }

        @Override
        public void onTextChanged(CharSequence s, int a, int b, int c) {
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        selected = prefs.selected();

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(24), dp(16), dp(32));
        sv.addView(col, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(sv);

        col.addView(text("Jumpscare Bekçisi", 26, TEXT, true), lp(0));
        col.addView(text("Seçtiğin uygulamalara girince seni korkutur.", 14, SUB, false), lp(4));

        // --- İzin kartı ---
        LinearLayout permCard = card();
        permStatus = text("", 17, TEXT, true);
        permCard.addView(permStatus, lp(0));
        permCard.addView(text(
                "Uygulamanın çalışması için Erişilebilirlik izni gerekir. Bu izin yalnızca hangi "
                        + "uygulamanın açıldığını görmek ve jumpscare'i göstermek için kullanılır; ekrandaki "
                        + "yazıları okumaz. \"Diğer uygulamaların üstünde göster\" izni istemez.",
                13, SUB, false), lp(6));
        permBtn = button("İzni ver", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                Toast.makeText(MainActivity.this,
                        "Listeden \"Jumpscare Bekçisi\"ni bulup aç", Toast.LENGTH_LONG).show();
            }
        });
        permCard.addView(permBtn, lp(10));
        permCard.addView(text(
                "İzin düğmesi gri ve kapalıysa (Android 13+): Uygulama bilgisi'ni aç, sağ üstteki "
                        + "⋮ menüsünden \"Kısıtlı ayarlara izin ver\"i seç, sonra tekrar dene.",
                12, SUB, false), lp(8));
        permCard.addView(button("Uygulama bilgisini aç", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        }), lp(6));
        col.addView(permCard, lp(16));

        // --- Ayarlar kartı ---
        LinearLayout setCard = card();
        setCard.addView(toggle("Koruma aktif", prefs.enabled(),
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton v, boolean on) {
                        prefs.setEnabled(on);
                    }
                }), lp(0));
        numberField(setCard, "Günlük süre sınırı (dakika)\n0 = sınırsız, her girişte korkut",
                prefs.limitMin(), new IntConsumer() {
                    @Override
                    public void accept(int v) {
                        prefs.setLimitMin(v);
                    }
                });
        numberField(setCard, "İki korkutma arası en az (saniye)", prefs.cooldownSec(),
                new IntConsumer() {
                    @Override
                    public void accept(int v) {
                        prefs.setCooldownSec(v);
                    }
                });
        setCard.addView(toggle("Ses çal", prefs.sound(),
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton v, boolean on) {
                        prefs.setSound(on);
                    }
                }), lp(10));
        setCard.addView(toggle("Korkuttuktan sonra ana ekrana at", prefs.kickHome(),
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton v, boolean on) {
                        prefs.setKickHome(on);
                    }
                }), lp(6));
        col.addView(setCard, lp(12));

        // --- Sayaç + test kartı ---
        LinearLayout useCard = card();
        usageTv = text("", 15, TEXT, false);
        useCard.addView(usageTv, lp(0));
        useCard.addView(button("Sayacı sıfırla", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.resetUsed();
                refreshStatus();
            }
        }), lp(8));
        useCard.addView(button("Jumpscare'i test et", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GuardService s = GuardService.instance;
                if (s == null) {
                    Toast.makeText(MainActivity.this,
                            "Önce Erişilebilirlik iznini ver", Toast.LENGTH_LONG).show();
                } else {
                    s.showScare();
                }
            }
        }), lp(4));
        col.addView(useCard, lp(12));

        // --- Uygulama listesi ---
        col.addView(text("Korkutulacak uygulamalar", 18, TEXT, true), lp(20));
        countTv = text("", 13, SUB, false);
        col.addView(countTv, lp(2));
        updateCount();

        EditText search = new EditText(this);
        search.setHint("Ara…");
        search.setHintTextColor(SUB);
        search.setTextColor(TEXT);
        search.setSingleLine(true);
        search.addTextChangedListener(new Watcher() {
            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
        col.addView(search, lp(8));

        appBox = new LinearLayout(this);
        appBox.setOrientation(LinearLayout.VERTICAL);
        appBox.addView(text("Uygulamalar yükleniyor…", 14, SUB, false), lp(8));
        col.addView(appBox, lp(4));

        loadApps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(refresh);
        handler.post(refresh);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(refresh);
        super.onPause();
    }

    private void loadApps() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                PackageManager pm = getPackageManager();
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> ris = pm.queryIntentActivities(i, 0);
                Set<String> seen = new HashSet<String>();
                final List<AppItem> items = new ArrayList<AppItem>();
                for (ResolveInfo ri : ris) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                    AppItem it = new AppItem();
                    it.pkg = pkg;
                    it.label = String.valueOf(ri.loadLabel(pm));
                    it.icon = ri.loadIcon(pm);
                    items.add(it);
                }
                Collections.sort(items, new Comparator<AppItem>() {
                    @Override
                    public int compare(AppItem a, AppItem b) {
                        return a.label.compareToIgnoreCase(b.label);
                    }
                });
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        populate(items);
                    }
                });
            }
        }).start();
    }

    private void populate(List<AppItem> items) {
        appBox.removeAllViews();
        rows.clear();
        for (final AppItem it : items) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(4), dp(8), dp(4), dp(8));

            ImageView icon = new ImageView(this);
            icon.setImageDrawable(it.icon);
            row.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));

            TextView name = text(it.label, 16, TEXT, false);
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            nlp.leftMargin = dp(12);
            row.addView(name, nlp);

            final CheckBox cb = new CheckBox(this);
            cb.setChecked(selected.contains(it.pkg));
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton v, boolean on) {
                    if (on) {
                        selected.add(it.pkg);
                    } else {
                        selected.remove(it.pkg);
                    }
                    prefs.setSelected(selected);
                    updateCount();
                }
            });
            row.addView(cb, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cb.toggle();
                }
            });

            AppRow r = new AppRow();
            r.pkg = it.pkg;
            r.label = it.label;
            r.view = row;
            rows.add(r);
            appBox.addView(row, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        if (rows.isEmpty()) {
            appBox.addView(text("Uygulama bulunamadı.", 14, SUB, false), lp(8));
        }
    }

    private void filter(String q) {
        String query = q.trim().toLowerCase(Locale.getDefault());
        for (AppRow r : rows) {
            boolean show = query.isEmpty()
                    || r.label.toLowerCase(Locale.getDefault()).contains(query);
            r.view.setVisibility(show ? View.VISIBLE : View.GONE);
        }
    }

    private void updateCount() {
        countTv.setText(selected.size() + " uygulama seçili");
    }

    private boolean serviceEnabled() {
        String enabled = Settings.Secure.getString(
                getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        ComponentName me = new ComponentName(this, GuardService.class);
        String full = me.flattenToString();
        String shortName = me.flattenToShortString();
        for (String s : enabled.split(":")) {
            if (s.equalsIgnoreCase(full) || s.equalsIgnoreCase(shortName)) return true;
        }
        return false;
    }

    private void refreshStatus() {
        boolean on = serviceEnabled();
        permStatus.setText(on ? "İzin durumu: AÇIK ✓" : "İzin durumu: KAPALI ✗");
        permStatus.setTextColor(on ? 0xFF66BB6A : ACCENT);
        permBtn.setText(on ? "Erişilebilirlik ayarlarını aç" : "İzni ver");
        long s = prefs.usedToday() / 1000;
        usageTv.setText(String.format(Locale.getDefault(),
                "Bugün seçili uygulamalarda: %d dk %02d sn", s / 60, s % 60));
    }

    // ---- küçük arayüz yardımcıları ----

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(topDp);
        return p;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(12));
        c.setBackground(g);
        return c;
    }

    private Button button(String label, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(label);
        bt.setAllCaps(false);
        bt.setOnClickListener(l);
        return bt;
    }

    private Switch toggle(String label, boolean initial, CompoundButton.OnCheckedChangeListener l) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(TEXT);
        s.setChecked(initial);
        s.setOnCheckedChangeListener(l);
        return s;
    }

    private void numberField(LinearLayout parent, String label, int initial, final IntConsumer onChange) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(text(label, 14, TEXT, false),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setTextColor(TEXT);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setText(String.valueOf(initial));
        e.addTextChangedListener(new Watcher() {
            @Override
            public void afterTextChanged(Editable s) {
                int v = 0;
                try {
                    v = Integer.parseInt(s.toString().trim());
                } catch (Exception ignored) {
                }
                onChange.accept(v);
            }
        });
        r.addView(e, new LinearLayout.LayoutParams(dp(90), ViewGroup.LayoutParams.WRAP_CONTENT));
        parent.addView(r, lp(12));
    }
}
