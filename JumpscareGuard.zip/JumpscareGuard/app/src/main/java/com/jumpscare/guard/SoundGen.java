package com.jumpscare.guard;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

import java.util.Random;

/** Dosya gerektirmeden, kodla üretilen çığlık benzeri bozuk bir ses. */
final class SoundGen {
    private volatile boolean stopped;
    private AudioTrack track;

    void play() {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                generateAndPlay();
            }
        });
        t.start();
    }

    private void generateAndPlay() {
        try {
            final int sr = 22050;
            final int n = (int) (sr * 1.8);
            short[] buf = new short[n];
            Random r = new Random();
            double phase = 0;
            double phase2 = 0;
            for (int i = 0; i < n; i++) {
                double tt = (double) i / sr;
                double env;
                if (tt < 0.02) {
                    env = tt / 0.02;
                } else if (tt < 1.2) {
                    env = 1.0;
                } else {
                    env = Math.max(0.0, 1.0 - (tt - 1.2) / 0.6);
                }
                double f = 500 + 900 * Math.min(1.0, tt / 0.5) + 70 * Math.sin(2 * Math.PI * 9 * tt);
                phase += 2 * Math.PI * f / sr;
                phase2 += 2 * Math.PI * (f * 1.51) / sr;
                double s = 0.6 * Math.sin(phase)
                        + 0.4 * Math.sin(2 * phase)
                        + 0.3 * Math.sin(3 * phase)
                        + 0.5 * Math.sin(phase2)
                        + 0.5 * (r.nextDouble() * 2 - 1);
                s = Math.tanh(s * 2.5);
                buf[i] = (short) (s * env * 32767 * 0.95);
            }

            synchronized (this) {
                if (stopped) return;
                AudioTrack at = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(sr)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build())
                        .setBufferSizeInBytes(n * 2)
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build();
                at.write(buf, 0, n);
                at.play();
                track = at;
            }
        } catch (Exception ignored) {
            // ses çalınamazsa görüntü yine de gösterilir
        }
    }

    synchronized void stop() {
        stopped = true;
        if (track != null) {
            try {
                track.stop();
            } catch (Exception ignored) {
            }
            try {
                track.release();
            } catch (Exception ignored) {
            }
            track = null;
        }
    }
}
