package com.jumpscare.guard;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Ayarlar ve günlük kullanım sayacı. */
final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("cfg", Context.MODE_PRIVATE);
    }

    boolean enabled() {
        return sp.getBoolean("enabled", true);
    }

    void setEnabled(boolean v) {
        sp.edit().putBoolean("enabled", v).apply();
    }

    Set<String> selected() {
        return new HashSet<String>(sp.getStringSet("sel", new HashSet<String>()));
    }

    void setSelected(Set<String> s) {
        sp.edit().putStringSet("sel", new HashSet<String>(s)).apply();
    }

    /** Günlük süre sınırı (dakika). 0 = sınırsız: seçili uygulamaya her girişte korkut. */
    int limitMin() {
        return sp.getInt("limit", 0);
    }

    void setLimitMin(int v) {
        sp.edit().putInt("limit", Math.max(0, Math.min(v, 1440))).apply();
    }

    /** İki korkutma arasındaki en kısa süre (saniye). */
    int cooldownSec() {
        return sp.getInt("cooldown", 30);
    }

    void setCooldownSec(int v) {
        sp.edit().putInt("cooldown", Math.max(5, Math.min(v, 3600))).apply();
    }

    boolean kickHome() {
        return sp.getBoolean("kickHome", false);
    }

    void setKickHome(boolean v) {
        sp.edit().putBoolean("kickHome", v).apply();
    }

    boolean sound() {
        return sp.getBoolean("sound", true);
    }

    void setSound(boolean v) {
        sp.edit().putBoolean("sound", v).apply();
    }

    private String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    /** Bugün seçili uygulamalarda geçirilen süre (ms). */
    long usedToday() {
        if (!today().equals(sp.getString("day", ""))) return 0;
        return sp.getLong("used", 0);
    }

    void addUsed(long ms) {
        String d = today();
        long cur = d.equals(sp.getString("day", "")) ? sp.getLong("used", 0) : 0;
        sp.edit().putString("day", d).putLong("used", cur + ms).apply();
    }

    void resetUsed() {
        sp.edit().putString("day", today()).putLong("used", 0).apply();
    }
}
