package com.jumpscare.guard;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.media.AudioAttributes;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;

import java.util.Random;

/** Tamamen kodla çizilen korkutucu yüz + ses + titreşim. Hiç görsel/ses dosyası gerekmez. */
class ScareView extends View {
    private static final long DURATION = 2600;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vig = new Paint();
    private final Path path = new Path();
    private final Random rnd = new Random();

    private ValueAnimator anim;
    private float t = 0f;
    private boolean finished;
    private Runnable onDone;
    private SoundGen sound;

    ScareView(Context c) {
        super(c);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        vig.setShader(new RadialGradient(
                w / 2f, h / 2f, Math.max(w, h) * 0.75f,
                new int[]{Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(230, 0, 0, 0)},
                new float[]{0f, 0.45f, 1f},
                Shader.TileMode.CLAMP));
    }

    void start(boolean withSound, boolean withVibrate, Runnable done) {
        onDone = done;
        if (withSound) {
            sound = new SoundGen();
            sound.play();
        }
        if (withVibrate) vibrate();
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(DURATION);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                t = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator a) {
                finish();
            }
        });
        anim.start();
    }

    /** Dışarıdan durdurma (geri çağrı tetiklemez). */
    void stop() {
        finished = true;
        if (anim != null) anim.cancel();
        if (sound != null) sound.stop();
    }

    private void finish() {
        if (finished) return;
        finished = true;
        if (sound != null) sound.stop();
        if (onDone != null) onDone.run();
    }

    @SuppressWarnings("deprecation")
    private void vibrate() {
        try {
            Vibrator v = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;
            long[] pattern = {0, 300, 80, 300, 80, 700};
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .build();
            v.vibrate(VibrationEffect.createWaveform(pattern, -1), attrs);
        } catch (Exception ignored) {
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN && t > 0.5f) {
            finish();
        }
        return true; // dokunuşları alttaki uygulamaya geçirme
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth();
        int h = getHeight();
        float m = Math.min(w, h);

        // Arka plan: ilk anda siyah, sonra kırmızı/siyah titreme
        boolean flick = ((int) (t * 36)) % 2 == 0;
        if (t < 0.10f) {
            c.drawColor(Color.BLACK);
        } else {
            c.drawColor(flick ? Color.rgb(90, 0, 0) : Color.BLACK);
        }

        // Yüzün büyüklüğü: önce küçük, sonra ani yaklaşma
        float s;
        if (t < 0.12f) {
            s = 0.20f + 0.10f * (t / 0.12f);
        } else if (t < 0.25f) {
            float k = (t - 0.12f) / 0.13f;
            s = 0.30f + 1.0f * (1f - (1f - k) * (1f - k));
        } else {
            s = 1.30f + 0.20f * ((t - 0.25f) / 0.75f);
        }

        float amp = t < 0.25f ? 0f : m * 0.015f * (0.5f + t);
        float dx = (rnd.nextFloat() - 0.5f) * 2f * amp;
        float dy = (rnd.nextFloat() - 0.5f) * 2f * amp;
        float cx = w / 2f + dx;
        float cy = h / 2f + dy;
        float R = m * 0.38f * s;

        p.setStyle(Paint.Style.FILL);

        // Baş
        p.setColor(Color.rgb(196, 190, 172));
        c.drawOval(cx - R * 0.85f, cy - R * 1.15f, cx + R * 0.85f, cy + R * 1.15f, p);

        // Göz çukurları
        float ex = R * 0.36f;
        float ey = cy - R * 0.25f;
        p.setColor(Color.rgb(25, 0, 0));
        c.drawOval(cx - ex - R * 0.30f, ey - R * 0.26f, cx - ex + R * 0.30f, ey + R * 0.26f, p);
        c.drawOval(cx + ex - R * 0.30f, ey - R * 0.26f, cx + ex + R * 0.30f, ey + R * 0.26f, p);

        // Göz yuvarları
        p.setColor(Color.rgb(245, 240, 230));
        c.drawCircle(cx - ex, ey, R * 0.20f, p);
        c.drawCircle(cx + ex, ey, R * 0.20f, p);

        // Damarlar
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1.5f, R * 0.008f));
        p.setColor(Color.rgb(170, 0, 0));
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4 + 0.3;
            float cs = (float) Math.cos(a);
            float sn = (float) Math.sin(a);
            c.drawLine(cx - ex + cs * R * 0.10f, ey + sn * R * 0.10f,
                    cx - ex + cs * R * 0.19f, ey + sn * R * 0.19f, p);
            c.drawLine(cx + ex + cs * R * 0.10f, ey + sn * R * 0.10f,
                    cx + ex + cs * R * 0.19f, ey + sn * R * 0.19f, p);
        }
        p.setStyle(Paint.Style.FILL);

        // Iris ve gözbebeği (titrek)
        float jx = (rnd.nextFloat() - 0.5f) * R * 0.03f;
        float jy = (rnd.nextFloat() - 0.5f) * R * 0.03f;
        p.setColor(Color.rgb(200, 0, 0));
        c.drawCircle(cx - ex + jx, ey + jy, R * 0.11f, p);
        c.drawCircle(cx + ex + jx, ey + jy, R * 0.11f, p);
        p.setColor(Color.BLACK);
        c.drawCircle(cx - ex + jx, ey + jy, R * 0.045f, p);
        c.drawCircle(cx + ex + jx, ey + jy, R * 0.045f, p);

        // Kızgın kaşlar
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(R * 0.07f);
        p.setColor(Color.BLACK);
        c.drawLine(cx - ex - R * 0.32f, ey - R * 0.50f, cx - ex + R * 0.30f, ey - R * 0.27f, p);
        c.drawLine(cx + ex + R * 0.32f, ey - R * 0.50f, cx + ex - R * 0.30f, ey - R * 0.27f, p);
        p.setStyle(Paint.Style.FILL);

        // Burun delikleri
        p.setColor(Color.rgb(60, 40, 40));
        c.drawOval(cx - R * 0.10f, cy + R * 0.08f, cx - R * 0.03f, cy + R * 0.18f, p);
        c.drawOval(cx + R * 0.03f, cy + R * 0.08f, cx + R * 0.10f, cy + R * 0.18f, p);

        // Ağız: çene aşağı iner
        float open = Math.max(0f, Math.min(1f, (t - 0.12f) / 0.15f));
        float mh = R * (0.15f + 0.60f * open);
        float left = cx - R * 0.50f;
        float right = cx + R * 0.50f;
        float top = cy + R * 0.32f;
        float bottom = top + mh;
        p.setColor(Color.rgb(30, 0, 0));
        c.drawRoundRect(left, top, right, bottom, R * 0.18f, R * 0.18f, p);

        // Dişler
        p.setColor(Color.rgb(235, 228, 200));
        int n = 9;
        float tw = (right - left) / n;
        for (int i = 0; i < n; i++) {
            float x0 = left + i * tw;
            path.reset();
            path.moveTo(x0, top);
            path.lineTo(x0 + tw, top);
            path.lineTo(x0 + tw / 2f, top + mh * 0.38f);
            path.close();
            c.drawPath(path, p);

            path.reset();
            path.moveTo(x0, bottom);
            path.lineTo(x0 + tw, bottom);
            path.lineTo(x0 + tw / 2f, bottom - mh * 0.32f);
            path.close();
            c.drawPath(path, p);
        }

        // Karartma (kenarlar)
        c.drawRect(0, 0, w, h, vig);

        // Yaklaşma anında beyaz flaş
        if (t > 0.24f && t < 0.30f) {
            c.drawColor(Color.argb(150, 255, 255, 255));
        }

        // Sonda kararma
        if (t > 0.92f) {
            int a = (int) ((t - 0.92f) / 0.08f * 255f);
            c.drawColor(Color.argb(Math.min(255, a), 0, 0, 0));
        }
    }
}
