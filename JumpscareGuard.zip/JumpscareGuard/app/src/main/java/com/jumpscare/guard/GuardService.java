package com.jumpscare.guard;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/**
 * Hangi uygulamanın açıldığını görür (yalnızca paket adı), seçili uygulamaya girilince
 * jumpscare gösterir ve seçili uygulamalarda geçen günlük süreyi sayar.
 *
 * Jumpscare, "diğer uygulamaların üstünde göster" izni istemeden, erişilebilirlik
 * hizmetinin kendi pencere türüyle (TYPE_ACCESSIBILITY_OVERLAY) çizilir.
 */
public class GuardService extends AccessibilityService {
    static volatile GuardService instance;

    private static final long TICK_MS = 3000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private WindowManager wm;
    private ScareView scareView;
    private boolean scareShowing;
    private String current = "";
    private long lastTick;
    private long lastScare;
    private long ignoreOwnUntil;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            onTick();
            handler.postDelayed(this, TICK_MS);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        prefs = new Prefs(this);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        lastTick = SystemClock.elapsedRealtime();
        handler.removeCallbacks(ticker);
        handler.postDelayed(ticker, TICK_MS);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null || prefs == null) return;
        if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence cs = e.getPackageName();
        if (cs == null) return;
        String pkg = cs.toString();
        if (ignored(pkg)) return;
        if (pkg.equals(current)) return;

        account();
        current = pkg;

        if (!prefs.enabled()) return;
        if (prefs.selected().contains(pkg)) {
            int limit = prefs.limitMin();
            if (limit == 0 || prefs.usedToday() >= limit * 60000L) {
                maybeScare();
            }
        }
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        shutdown();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        shutdown();
        super.onDestroy();
    }

    private void shutdown() {
        handler.removeCallbacks(ticker);
        hideScare();
        if (instance == this) instance = null;
    }

    /** Klavye ve sistem arayüzü gibi "uygulama değiştirmeyen" pencereleri yok say. */
    private boolean ignored(String pkg) {
        if (pkg.equals("com.android.systemui") || pkg.equals("android")) return true;
        if (pkg.equals(getPackageName())) {
            return scareShowing || SystemClock.elapsedRealtime() < ignoreOwnUntil;
        }
        return pkg.equals(imePackage());
    }

    private String imePackage() {
        try {
            String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
            if (id == null) return "";
            ComponentName cn = ComponentName.unflattenFromString(id);
            return cn == null ? "" : cn.getPackageName();
        } catch (Exception e) {
            return "";
        }
    }

    private boolean interactive() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isInteractive();
    }

    /** Son sayımdan bu yana geçen süreyi, o an seçili bir uygulamadaysak günlük sayaca ekler. */
    private void account() {
        long now = SystemClock.elapsedRealtime();
        long dt = now - lastTick;
        lastTick = now;
        if (dt <= 0 || dt > 10000) return; // uyku/gecikme sonrası güvenilmez süreyi atla
        if (!current.isEmpty() && prefs.selected().contains(current) && interactive()) {
            prefs.addUsed(dt);
        }
    }

    private void onTick() {
        if (prefs == null) return;
        account();
        if (!prefs.enabled() || scareShowing) return;
        if (current.isEmpty() || !prefs.selected().contains(current) || !interactive()) return;
        int limit = prefs.limitMin();
        if (limit > 0 && prefs.usedToday() >= limit * 60000L) {
            maybeScare(); // süre dolduktan sonra, bekleme süresi geçtikçe tekrar korkut
        }
    }

    private void maybeScare() {
        if (scareShowing) return;
        long now = SystemClock.elapsedRealtime();
        if (lastScare != 0 && now - lastScare < prefs.cooldownSec() * 1000L) return;
        showScare();
    }

    /** Bekleme süresine bakmadan hemen gösterir (test düğmesi de bunu kullanır). */
    void showScare() {
        if (scareShowing || wm == null) return;
        scareShowing = true;
        lastScare = SystemClock.elapsedRealtime();
        try {
            ScareView v = new ScareView(this);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            wm.addView(v, lp);
            scareView = v;
            v.start(prefs.sound(), true, new Runnable() {
                @Override
                public void run() {
                    hideScare();
                }
            });
        } catch (Exception ex) {
            scareView = null;
            scareShowing = false;
        }
    }

    private void hideScare() {
        boolean wasShowing = scareShowing;
        if (scareView != null) {
            scareView.stop();
            try {
                wm.removeView(scareView);
            } catch (Exception ignored) {
            }
            scareView = null;
        }
        scareShowing = false;
        ignoreOwnUntil = SystemClock.elapsedRealtime() + 1500;
        if (wasShowing && prefs != null && prefs.kickHome()) {
            performGlobalAction(GLOBAL_ACTION_HOME);
        }
    }
}
